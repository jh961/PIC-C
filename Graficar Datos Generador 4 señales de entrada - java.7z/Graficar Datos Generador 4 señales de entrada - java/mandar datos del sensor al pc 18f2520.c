#include <18f2520.h>
#DEVICE ADC=10
#fuses HS,NOWDT,NOPROTECT,NOLVP,PUT,BROWNOUT
//#FUSES CPUDIV1         //DIVISION DE FRECUENCIA DEL OSCILADOR: 1
#use delay(clock=20000000)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7,STREAM=pc 1)
#include <stdio.h>
//#include <lcd.c>

char a,dt1;
char dato[100]={};
float valor,valor1,valor2,valor3,valor4;
int e=0,k,d=1,p1,p2,dt2;


#int_rda
void rda_isr()
   {
   output_high(PIN_b0);
   a=fgetc();
   if(a=='@'){
   k=1;
   e=100;
   dato[0]=a;
   }
   if(k==1){
      for(d=1;d<=e;d++) {
      a=fgetc();
      dato[d]=a;
      if(a==','){
       p1=d;
      }else if(a=='#'){
      p2=d;
      e=0;
      }
     }
   }
   dt1=dato[1];
    if(((dato[p1+1]-48)<=9)&&((dato[p2-2]==','))) {
    dt2=(dato[p1+1]-48);
   }else {
    dt2=(dato[p2-1]-48)+10;
   }
    k=0;  
   }
   

void main()
{
   set_tris_a (0xff);
   set_tris_b (0xff);

   enable_interrupts(int_rda);
   enable_interrupts(GLOBAL);

   setup_adc (ADC_CLOCK_div_8);
   setup_adc_ports (AN0_TO_AN3);
   set_adc_channel (0);
   delay_us (10) ;
       
    while(true){
    
   
    set_adc_channel (0);
    delay_us (10) ;
    valor = read_adc ();
    valor1=(valor/3.41);
   
    set_adc_channel (1);
    delay_us (10) ;
    valor = read_adc ();
    valor2=(valor/3.41);
    
    set_adc_channel (2);
    delay_us (10) ;
    valor = read_adc ();
    valor3=(valor/3.41);
    
    set_adc_channel (3);
    delay_us (10) ;
    valor = read_adc ();
    valor4=(valor/3.41);
    delay_ms(15);
    
    
    
    output_toggle (pin_b0);
    
   
    
    printf ("@%03.0f?%03.0f$%03.0f&%03.0f#",valor1,valor2,valor3,valor4);
    delay_ms(15);
     
    }
   }
 /*
AUTOR 
Jaime Hernando diaz padilla
20141573116
*/
