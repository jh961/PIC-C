#include <18f4550.h>
#DEVICE ADC=10
#fuses HS,NOWDT,NOPROTECT,NOLVP,PUT,BROWNOUT
#FUSES CPUDIV1         //DIVISION DE FRECUENCIA DEL OSCILADOR: 1
#use delay(clock=20000000)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7,STREAM=pc 1)
#include <stdio.h>
//#include <lcd.c>

char a,dt1;
char dato[100]={};
float valor,valor1;
int e=0,k,d=1,p1,p2,dt2,to=0,g=0;
/*
frecuencia =10k
tiempo deseado= 1/(frecuencia*2)
cristal/ reloj = 20Mhz
division de crital=t2_div_b_#/cristal
setup_timer_1(t1_internal|t1_div_by_#);
set_timer1(time);

Time = 65536-((tiempo requerido)/(4/division de crital))
frecuencia =(1/ perido PWM)*2 
*/

#int_rda
void rda_isr()
   {
   output_high(PIN_b1);
   a=fgetc();
   if(a=='@'){
   k=1;
   e=100;
   dato[0]=a;
   }
   if(k==1){
      for(d=1;d<=e;d++) {
      a=fgetc();
      dato[d]=a;
      if(a==','){
       p1=d;
      }else if(a=='#'){
      p2=d;
      e=0;
      }
     }
   }
   dt1=dato[1];
    if(((dato[p1+1]-48)<=9)&&((dato[p2-2]==','))) {
    dt2=(dato[p1+1]-48);
   }else {
    dt2=(dato[p2-1]-48)+10;
   }
    k=0;  
   }
   
/*
#int_TIMER1 //interrupcion timer1 
void TIMER1(void) //funcion que se ejecutara al desbordar timer1 
{ 
//set_timer1(10); // se vuelve a cargar valor de timer1 
output_toggle(PIN_b0);
if(g==10){
 if ((dt1=='B')&&(to>0)){
to--;
 }
 g=0;
}
g++;
} 
*/
void main()
{
   set_tris_a (0xff);
   set_tris_b (0xff);
   //set_tris_d (0x00);
/*   
   lcd_init ();
   
   printf (lcd_putc, "AUTOR");
   lcd_gotoxy (1, 2) ;
   printf (lcd_putc, "JAIME DIAZ");
   delay_ms (1000);
   lcd_putc ('\f');
   */
   //enable_interrupts (INT_TIMER1); // avilita la interruccion por derrame
   enable_interrupts(int_rda);
   enable_interrupts(GLOBAL);
 
   
  // setup_timer_1(T1_INTERNAL|T1_DIV_BY_8); //configura timer1 interno con division de 8 
   
   setup_adc (ADC_CLOCK_div_8);
   setup_adc_ports (AN0);
   set_adc_channel (0);
   delay_us (10) ;
       
    while(true){
    
    valor = read_adc ();
    valor1=valor/1.33;
    output_low (pin_b1);
    
    /*
    if((dt1=='B')&&(to==0)){
     output_low (pin_b2);
     lcd_putc('\f');
    lcd_gotoxy (1, 1) ;
    printf (lcd_putc, "Dato Enviado");
    lcd_gotoxy (1, 2) ;
    printf (lcd_putc, "%03.0f",valor1);
     }else if(dt1=='A'){
     lcd_putc('\f');
    lcd_gotoxy (1, 1) ;
    printf (lcd_putc, "ALARMA %u", to);
    lcd_gotoxy (1, 2) ;
    //printf (lcd_putc, "%03.0f",valor1);
     printf (lcd_putc,"%03.0f",valor1);
     to=dt2;
      output_high (pin_b2);
     }ELSE if((dt1=='B')&&(to>0)){
     output_high (pin_b2);
     lcd_putc('\f');
    lcd_gotoxy (1, 1) ;
    printf (lcd_putc, "ALARMA %u", to);
    lcd_gotoxy (1, 2) ;
    printf (lcd_putc, "%03.0f",valor1);
     }
     */
  //////////////////////envio de datos
    //fputc('@');
    printf ("@%03.0f#",valor1);
   // fputc('#');
    delay_ms(50);
     
    }
   }
 /*
AUTOR 
Jaime Hernando diaz padilla
20141573116
*/

